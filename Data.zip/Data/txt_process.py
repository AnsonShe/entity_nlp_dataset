# 打开文件并读取内容
with open('新华社网址.txt', 'r') as file:
    lines = file.readlines()

import re

def is_seven_digit_end(line):
    # 使用正则表达式匹配七位数字结尾
    pattern = re.compile(r'\d{7}$')
    return bool(pattern.search(line))


def contains_keywords(text):
    keywords = ["world", "politics"]
    for keyword in keywords:
        if keyword in text:
            return True

    return False

# 过滤不符合条件的行
filtered_lines = [line for line in lines if (line.startswith('https:') and is_seven_digit_end(line) and contains_keywords(line))]

# 将过滤后的内容写回文件
with open('TVBS网址2.txt', 'w') as file:
    file.writelines(filtered_lines)
