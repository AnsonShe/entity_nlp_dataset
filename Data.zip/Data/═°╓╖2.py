import soupsieve
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup


def scrape_url(driver):
    rep = driver.page_source
    soup = BeautifulSoup(rep, 'lxml')
    divs = soup.select('ul.news_list_ul[id="ent0"] li')

    urls = []
    for div in divs:
        a_tag = div.select_one('div[class="topcon"] a')
        if a_tag:
            href_value = a_tag.get('href')
            urls.append(href_value)
        else:
            continue
    return urls


def main():
    base_url = 'https://channel.chinanews.com.cn/u/gn-la.shtml?pager='
    start_page = 0
    end_page = 99  # 设置你想要爬取的页数

    driver = webdriver.Chrome()  # 使用Chrome浏览器，确保已经下载了对应版本的ChromeDriver并配置到系统PATH中

    all_urls = []
    for page_num in range(start_page, end_page + 1):
        url = base_url + str(page_num)
        driver.get(url)

        # 等待页面加载完成，可根据实际情况调整等待时间
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "ul.news_list_ul[id='ent0'] li")))
        page_url = scrape_url(driver)
        all_urls.extend(page_url)

    driver.quit()  # 关闭浏览器

    with open('中国新闻网址.txt', 'w', encoding='utf-8') as f:
        for item in all_urls:
            f.write(item + '\n')
            print(item, end='\n')

    print(len(all_urls))



if __name__ == '__main__':
    main()