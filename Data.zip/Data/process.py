import openpyxl
from opencc import OpenCC


def traditional_to_simplified(traditional_text):
    cc = OpenCC('t2s')  # 使用繁体转简体的规则
    simplified_text = cc.convert(traditional_text)
    return simplified_text


def convert_excel(input_file, output_file):
    wb = openpyxl.load_workbook(input_file)

    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]

        for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row, min_col=1, max_col=sheet.max_column):
            for cell in row:
                if isinstance(cell.value, str):
                    cell.value = traditional_to_simplified(cell.value)
    wb.save(output_file)

input_excel = 'TVBS_Summary.xlsx'
output_excel = 'simplified.xlsx'

convert_excel(input_excel, output_excel)
