import pandas as pd

# 读取Excel文件
excel_file_path = './分段数据/新华网分段版.xlsx'
df = pd.read_excel(excel_file_path)

# 定义关键词列表
keywords = ["两岸", "疫苗", "中美", "局势", "关系", "美中", "美国"]

filtered_df = df[df.apply(lambda row: any(keyword in str(row) for keyword in keywords), axis=1)]

# 保存过滤后的数据到新的Excel文件
filtered_excel_path = './最新数据集（已删减）/Xinhua news.xlsx'
filtered_df.to_excel(filtered_excel_path, index=False)

print(f"已保存过滤后的数据到: {filtered_excel_path}")