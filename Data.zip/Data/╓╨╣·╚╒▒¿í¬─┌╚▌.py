import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import pandas as pd

with open('中国日报网址.txt', 'r', encoding='utf-8') as f:
    sentence = []
    for line in f:
        url = line.strip()
        url = 'https:' + url
        rep = requests.get(url)
        rep.encoding = 'utf-8'
        html = rep.text
        soup = BeautifulSoup(html, 'lxml')
        divs = soup.select('div[id="Content"][class="article"] p')
        for div in divs:
            if len(div.text) != 0:
                sentence.append(div.text)

df = pd.DataFrame(sentence)
df.to_excel('中国日报分段版.xlsx', index=False)
print('保存成功！')