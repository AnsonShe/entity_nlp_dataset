import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'http://www.news.cn/tw/index.html'
data = []

# 创建一个浏览器实例
driver = webdriver.Edge()

def scrape_page():
    rep = driver.page_source
    # rep.encoding = 'utf-8'
    # html = rep.text
    soup = BeautifulSoup(rep, 'lxml')
    divs = driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1")
    # divs = soup.select("div.item.item-style1")
    print(len(divs))


    for div in divs:
        data_dict = {}
        title = div.find_element(By.TAG_NAME, 'span').text
        content = div.find_element(By.CSS_SELECTOR, '.abstract.domPc').text
        dt = div.find_element(By.CLASS_NAME, 'time').text
        data_dict['标题'] = title
        data_dict['发布时间'] = dt
        data_dict['内容'] = content
        data.append(data_dict)
        # print(title, content, dt)

# 打开初始页面
driver.get(url)

# 模拟点击“查看更多按钮”
max_clicks = 150  # 设置最大点击次数
click_count = 0
current_len = 0

while current_len != len(driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1")):
    current_len = len(driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1"))
    # try:
    # 使用WebDriverWait等待按钮加载，并点击
    more_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//div[@class="xpage-more-btn look"]'))
    )
    more_button.click()
    # 等待新内容加载完成，可以根据实际情况调整等待时间
    # WebDriverWait(driver, 10).until(
    #     EC.invisibility_of_element_located((By.CLASS_NAME, 'item item-style1'))
    # )
    time.sleep(3)
    click_count += 1
    # except Exception as e:
    #     print(f"An error occurred: {e}")
    #     break

# 关闭浏览器
scrape_page()
driver.quit()

df = pd.DataFrame(data)
df.to_excel('1.xlsx', index=False)
print(f'保存成功！')
