import soupsieve
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import pandas as pd
import time


def scrape_page(driver):
    rep = driver.page_source
    soup = BeautifulSoup(rep, 'lxml')
    divs = soup.select('div.news_list div.list ul li')

    data = []
    for div in divs:
        type = div.select_one('div[class="type"]').text
        content = div.select_one('div[class="summary"]').text
        if type not in ['全球', '政治']:
            continue
        else:
            data.append(content)
    return data

def save_to_excel(data, filename):
    df = pd.DataFrame(data)
    df.to_excel(filename, index=False)
    print(f'保存成功！')

def main():
    base_url = 'https://news.tvbs.com.tw/news/searchresult/%E4%B8%AD%E5%9C%8B%E5%A4%A7%E9%99%B8/news/'
    start_page = 1
    end_page = 400  # 设置你想要爬取的页数

    driver = webdriver.Chrome()  # 使用Chrome浏览器，确保已经下载了对应版本的ChromeDriver并配置到系统PATH中

    all_datas = []
    for page_num in range(start_page, end_page + 1):
        url = base_url + str(page_num)
        driver.get(url)

        # 等待页面加载完成，可根据实际情况调整等待时间
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "news_list")))
        # time.sleep(3)
        page_data = scrape_page(driver)
        all_datas.extend(page_data)

    driver.quit()  # 关闭浏览器
    save_to_excel(all_datas, 'TVBS_Summary.xlsx')



if __name__ == '__main__':
    main()