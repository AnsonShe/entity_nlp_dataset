import soupsieve
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time


def scrape_url(driver):
    rep = driver.page_source
    soup = BeautifulSoup(rep, 'lxml')
    divs = soup.select('div.item.item-style1')

    urls = []
    for div in divs:
        tag = div.select_one('div[class="share"] div')
        if tag:
            html_value = tag.get('data-html')
            urls.append(html_value)
        else:
            continue
    return urls


def main():
    url = 'http://www.news.cn/tw/index.html'
    max_clicks = 3  # 设置最大点击次数
    click_count = 0
    current_len = 0

    driver = webdriver.Chrome()  # 使用Chrome浏览器，确保已经下载了对应版本的ChromeDriver并配置到系统PATH中
    driver.get(url)

    while current_len != len(driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1")):
        current_len = len(driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1"))
        more_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//div[@class="xpage-more-btn look"]'))
        )
        more_button.click()
        time.sleep(3)
        # click_count += 1

    # 关闭浏览器
    urls = scrape_url(driver)

    driver.quit()  # 关闭浏览器

    with open('新华社网址.txt', 'w', encoding='utf-8') as f:
        for item in urls:
            f.write(item + '\n')
            print(item, end='\n')

    print(len(urls))



if __name__ == '__main__':
    main()