import tweepy
import requests

# Twitter API 认证信息
consumer_key = '8o8NvyqC9GclwUPhHGYj0F9fW'
consumer_secret = 'ftY9tDyLKroG0BEx27yONm7xnlMV4XKDwrEkkZaLfo1cSXg78k'
# bearer_token = 'AAAAAAAAAAAAAAAAAAAAAD2wrAEAAAAAC1wsi5B02%2F4uap9Fv5y%2BDEq7PWI%3DDYmPlKg7JDXsRH9OygJR7EXFjCoeHKK7zcaC2w33J9eYQFE6Rl'
bearer_token = 'AAAAAAAAAAAAAAAAAAAAAD2wrAEAAAAAThxVrg%2BpzLEPa8w9Uke85n4DLF8%3DUe4COoRumNxCaTLYznejH2mQiFk6mfmNSKmcC5Egy3rFarf48t'
access_token = '1597032393478934528-5a2gtPawI40jZhA96H4HNWSJB7Mydo'
access_token_secret = 'qBEIIWeosFMtaTTkO2XTeayXvCCD0tEbJLl10nM2kWkaL'
proxies = {
        'http': 'http://127.0.0.1:7890',
        'https': 'http://127.0.0.1:7890'
    }

search_query = '台湾问题'
# 使用 Bearer Token 进行认证

client = tweepy.Client(bearer_token=bearer_token)

tweets = client.search_recent_tweets(query=search_query, tweet_fields=['context_annotations', 'created_at'], max_results=100)

for tweet in tweets.data:
    print(tweet.text)
    if len(tweet.context_annotations) > 0:
        print(tweet.context_annotations)