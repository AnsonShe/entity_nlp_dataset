import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'http://www.news.cn/tw/index.html'
rep = requests.get(url)
rep.encoding = 'utf-8'
html = rep.text
soup = BeautifulSoup(html, 'lxml')
divs = soup.find_all('div', class_='item item-style1')
# print(divs)

data = []
for div in divs:
    data_dict = {}
    title = div.find('span').text
    content = div.find(class_='abstract domPc').text
    dt = div.find(class_='time').text
    data_dict['标题'] = title
    data_dict['发布时间'] = dt
    data_dict['内容'] = content
    data.append(data_dict)
    # print(title, content, dt)

df = pd.DataFrame(data)
df.to_excel('1.xlsx', index=False)
print(f'保存成功！')
