import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import pandas as pd


def scrape_page(driver):
    html = driver.page_source
    soup = BeautifulSoup(html, "lxml")
    lis = soup.select("ul.news_list_ul[id='ent0'] li")
    data = []
    for li in lis:
        data_dict = {}
        title = li.select_one('.news_title').text
        content = li.select_one('.news_content').text
        dt = li.select_one('.time').text
        data_dict['标题'] = title
        data_dict['发布时间'] = dt
        data_dict['内容'] = content
        data.append(data_dict)

    return data

def save_to_excel(data, filename):
    df = pd.DataFrame(data)
    df.to_excel(filename, index=False)
    print(f'保存成功！')

def main():
    base_url = 'https://channel.chinanews.com.cn/u/gn-la.shtml?pager='
    start_page = 0
    end_page = 2  # 设置你想要爬取的页数

    driver = webdriver.Chrome()  # 使用Chrome浏览器，确保已经下载了对应版本的ChromeDriver并配置到系统PATH中

    all_data = []
    for page_num in range(start_page, end_page + 1):
        url = base_url + str(page_num)
        driver.get(url)
        time.sleep(1)

        # 等待页面加载完成，可根据实际情况调整等待时间
        # WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "ul.news_list_ul[id='endt0'] li")))
        page_data = scrape_page(driver)
        all_data.extend(page_data)

    driver.quit()  # 关闭浏览器

    save_to_excel(all_data, '1.xlsx')

if __name__ == '__main__':
    main()