# README

## 项目介绍

本项目是针对爬取新华网、中国日报网、中国新闻网、TVBS NEWS、Twitter等新闻媒体平台的数据，对这些数据进行筛选、清洗等处理用于模型的训练和测试所建立的。



## 目录结构说明

### 数据文件

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20231215193726333.png" alt="image-20231215193726333" style="zoom:67%;" />

其中，分段数据是利用不同的爬虫程序所获取到的全部新闻数据（Twitter数据由于存在一些明显问题，已从该项目的数据中删除），最新数据集（已删减）是最终用于标注的数据集。

### 代码文件

初始数据爬虫程序：

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20231215195717349.png" alt="image-20231215195717349" style="zoom:67%;" />

新华网、中国日报网、中国新闻网的网址获取程序：

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20231215195851164.png" alt="image-20231215195851164" style="zoom:67%;" />

通过网址获取新闻内容程序：

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20231215200001536.png" alt="image-20231215200001536" style="zoom:67%;" />

台湾新闻获取爬虫程序：TVBS_summary.py

新闻处理程序：

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20231215200201868.png" alt="image-20231215200201868" style="zoom:67%;" />

cookie.json是用于模拟浏览器登陆Twitter的文件

TVBS_news_annotations.json是台湾新闻的标注文件

数据可视化.eddx是最终数据的可视化文件：

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20231215200450897.png" alt="image-20231215200450897" style="zoom: 50%;" />



## 使用说明

使用前，需要下载 soupsieve 、selenium、BeautifulSoup、pandas、openpyxl、OpenCC等软件包和库函数