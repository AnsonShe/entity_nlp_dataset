import json
import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'https://twitter.com/search?q=台湾'
data = []

# 创建一个浏览器实例
cookie_file = "cookie.json"
with open(cookie_file, "r") as f:
    cookie = json.load(f)
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--proxy-server=http://127.0.0.1:7890")
# chrome_options.add_argument("headless")
capabilities = DesiredCapabilities.CHROME
capabilities['goog:loggingPrefs'] = {"performance": "ALL"}
driver = webdriver.Chrome(options=chrome_options, desired_capabilities=capabilities)


def scrape_page():
    rep = driver.page_source
    # rep.encoding = 'utf-8'
    # html = rep.text
    soup = BeautifulSoup(rep, 'lxml')
    divs = driver.find_elements(By.CSS_SELECTOR, "div.css-175oi2r.r-1iusvr4.r-16y2uox.r-1777fci.r-kzbkwu")
    # divs = soup.select("div.item.item-style1")
    print(len(divs))

    for i, div in enumerate(divs):
        print(i)
        data_dict = {}
        content = div.find_element(By.CSS_SELECTOR,
                                   'div[data-testid="tweetText"]').text

        dt = div.find_element(By.TAG_NAME, 'time').get_attribute("datetime")
        data_dict['发布时间'] = dt
        data_dict['内容'] = content
        data.append(data_dict)
        # print(title, content, dt)


# 打开初始页面
driver.get(url)
for item in cookie:
    if item['sameSite'] not in ['Strict', 'Lax', 'None']:
        item['sameSite'] = 'Strict'
    driver.add_cookie(item)
driver.get(url)

# 模拟点击“查看更多按钮”
max_clicks = 150  # 设置最大点击次数
click_count = 0
current_len = 0

# while current_len != len(driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1")):
#     current_len = len(driver.find_elements(By.CSS_SELECTOR, "div.item.item-style1"))
#     # try:
#     # 使用WebDriverWait等待按钮加载，并点击
#     more_button = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.XPATH, '//div[@class="xpage-more-btn look"]'))
#     )
#     more_button.click()
#     # 等待新内容加载完成，可以根据实际情况调整等待时间
#     # WebDriverWait(driver, 10).until(
#     #     EC.invisibility_of_element_located((By.CLASS_NAME, 'item item-style1'))
#     # )
#     time.sleep(3)
#     click_count += 1
#     # except Exception as e:
#     #     print(f"An error occurred: {e}")
#     #     break

# 关闭浏览器
time.sleep(10)
scrape_page()
# driver.quit()

df = pd.DataFrame(data)
df.to_excel('1.xlsx', index=False)
print(f'保存成功！')
